package main

import (
	"fmt"
	"net/http"
	"strings"
	"time"
)

type Pair struct {
	Key   string
	Value int
}

// ================= ITERATIF WORD COUNT =================
func wordCountIterative(tweets []string) map[string]int {
	freq := make(map[string]int)
	for _, tweet := range tweets {
		words := strings.Fields(strings.ToLower(tweet))
		for _, w := range words {
			freq[w]++
		}
	}
	return freq
}

// ================= ITERATIF SORT (BUBBLE SORT) =================
func bubbleSort(freq map[string]int) []Pair {
	pairs := []Pair{}
	for k, v := range freq {
		pairs = append(pairs, Pair{k, v})
	}

	n := len(pairs)
	for i := 0; i < n-1; i++ {
		for j := 0; j < n-i-1; j++ {
			if pairs[j].Value < pairs[j+1].Value {
				pairs[j], pairs[j+1] = pairs[j+1], pairs[j]
			}
		}
	}
	return pairs
}

// ================= WEB HANDLER =================
func handler(w http.ResponseWriter, r *http.Request) {

	tweets := []string{
		"Cuaca hari ini panas banget",
		"Lagi hujan deras di beberapa wilayah",
		"Macet parah di jalan utama pagi ini",
		"Harga bahan pokok mulai naik",
		"Promo besar besaran di akhir bulan",
		"Banyak orang beralih ke transportasi umum",
		"Film baru ini ceritanya menarik",
		"Konser musik tadi malam ramai sekali",
		"Liga sepak bola makin seru",
		"Tim favorit menang besar semalam",
		"Kereta api terlambat pagi ini",
		"Aplikasi baru ini cukup membantu",
		"Update sistem bikin fitur baru",
		"Banyak pengguna mengeluhkan jaringan lambat",
		"Internet mati sejak pagi",
		"Acara olahraga disiarkan langsung",
		"Belanja online semakin diminati",
		"Diskon menarik di marketplace",
		"Makanan viral banyak diburu",
		"Restoran baru buka di pusat kota",
		"Liburan akhir pekan terasa singkat",
		"Banyak orang berbagi pengalaman perjalanan",
	}

	loop := 1000
	start := time.Now()

	var result []Pair
	for i := 0; i < loop; i++ {
		freq := wordCountIterative(tweets)
		result = bubbleSort(freq)
	}

	elapsed := time.Since(start)

	// ===== OUTPUT HTML =====
	fmt.Fprintln(w, "<html><head><title>Iteratif Trending</title></head><body>")
	fmt.Fprintln(w, "<h1>Analisis Trending (Iteratif)</h1>")

	fmt.Fprintln(w, "<h3>Top Trending Kata</h3>")
	fmt.Fprintln(w, "<ul>")
	for i := 0; i < 5 && i < len(result); i++ {
		fmt.Fprintf(w, "<li>%s : %d</li>", result[i].Key, result[i].Value)
	}
	fmt.Fprintln(w, "</ul>")

	fmt.Fprintf(w, "<p><b>Running Time Total:</b> %d ns</p>", elapsed.Nanoseconds())
	fmt.Fprintf(
		w,
		"<p><b>Running Time Rata-rata:</b> %.4f ms</p>",
		float64(elapsed.Nanoseconds())/float64(loop)/1_000_000,
	)

	fmt.Fprintln(w, "</body></html>")
}

// ================= MAIN =================
func main() {
	http.HandleFunc("/", handler)
	fmt.Println("Server berjalan di http://localhost:8080")
	http.ListenAndServe(":8080", nil)
}
