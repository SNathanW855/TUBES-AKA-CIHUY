package main

import (
	"fmt"
	"net/http"
	"strings"
	"time"
)

type Pair struct {
	Key   string
	Value int
}

// ================= REKURSIF WORD COUNT =================
func wordCountRecursive(tweets []string, idx int, freq map[string]int) {
	if idx == len(tweets) {
		return
	}

	words := strings.Fields(strings.ToLower(tweets[idx]))
	for _, w := range words {
		freq[w]++
	}

	wordCountRecursive(tweets, idx+1, freq)
}

// ================= MAX INDEX REKURSIF =================
func maxIndexRecursive(arr []Pair, n int) int {
	if n == 1 {
		return 0
	}

	idx := maxIndexRecursive(arr, n-1)
	if arr[n-1].Value > arr[idx].Value {
		return n - 1
	}
	return idx
}

// ================= REKURSIF SORT =================
func recursiveSort(arr []Pair, n int) {
	if n <= 1 {
		return
	}

	maxIdx := maxIndexRecursive(arr, n)
	arr[maxIdx], arr[n-1] = arr[n-1], arr[maxIdx]
	recursiveSort(arr, n-1)
}

// ================= WEB HANDLER =================
func handler(w http.ResponseWriter, r *http.Request) {

	tweets := []string{
		"Cuaca hari ini panas banget",
		"Lagi hujan deras di Bojongsoang",
		"Macet parah di Buah Batu",
		"Harga bahan pokok mulai naik",
		"Promo besar besaran di akhir bulan",
		"Banyak orang beralih ke transportasi umum",
		"Film baru avatar tayang di bioskop",
		"Konser musik bernadya ramai sekali",
		"Liga Inggris sepak bola makin seru",
		"Tim Indonesia menang besar semalam",
		"Kereta api terlambat pagi ini",
		"Aplikasi baru ini cukup membantu",
		"Update sistem bikin fitur baru",
		"Banyak pengguna mengeluhkan jaringan lambat",
		"Internet mati sejak pagi",
		"Acara olahraga disiarkan langsung di kompas TV",
		"Belanja online semakin diminati",
		"Diskon menarik di marketplace",
		"Makanan viral banyak diburu",
		"Restoran baru buka di pusat kota",
		"Liburan akhir pekan terasa singkat",
		"Banyak orang berbagi pengalaman perjalanan",
	}

	loop := 1000
	start := time.Now()

	var pairs []Pair

	for i := 0; i < loop; i++ {
		freq := make(map[string]int)
		wordCountRecursive(tweets, 0, freq)

		pairs = []Pair{}
		for k, v := range freq {
			pairs = append(pairs, Pair{k, v})
		}

		recursiveSort(pairs, len(pairs))
	}

	elapsed := time.Since(start)

	// ===== OUTPUT HTML =====
	fmt.Fprintln(w, "<html><head><title>Rekursif Trending</title></head><body>")
	fmt.Fprintln(w, "<h1>Analisis Trending (Rekursif)</h1>")

	fmt.Fprintln(w, "<h3>Top Trending Kata</h3>")
	fmt.Fprintln(w, "<ul>")
	for i := len(pairs) - 1; i >= 0 && i >= len(pairs)-5; i-- {
		fmt.Fprintf(w, "<li>%s : %d</li>", pairs[i].Key, pairs[i].Value)
	}
	fmt.Fprintln(w, "</ul>")

	fmt.Fprintf(w, "<p><b>Running Time Total:</b> %d ns</p>", elapsed.Nanoseconds())
	fmt.Fprintf(
		w,
		"<p><b>Running Time Rata-rata:</b> %.4f ms</p>",
		float64(elapsed.Nanoseconds())/float64(loop)/1_000_000,
	)

	fmt.Fprintln(w, "</body></html>")
}

// ================= MAIN =================
func main() {
	http.HandleFunc("/", handler)
	fmt.Println("Server berjalan di http://localhost:8081")
	http.ListenAndServe(":8081", nil)
}
